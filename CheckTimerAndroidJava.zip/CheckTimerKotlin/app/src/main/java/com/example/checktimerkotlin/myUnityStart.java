package com.example.checktimerkotlin;

import com.unity3d.player.UnityPlayer;

public class myUnityStart {
    private static myUnityStart mus_instance;

    // Constructor (private to prevent instantiation)
    private myUnityStart() {}

    // Get the Singleton Instance
    public static myUnityStart instance()
    {
        if(mus_instance == null) {
            mus_instance = new myUnityStart();
        }
        return mus_instance;
    }

    // Send text to Unity
    public void sendTextToUnity(String gameObjectName, String methodName, String message) {
        UnityPlayer.UnitySendMessage(gameObjectName, methodName, message);
    }

    // Unity communication
    public void TestUnity()
    {
        UnityPlayer.UnitySendMessage("StartUI", "UpdateButtonText", "Go To Next!");
    }
}
